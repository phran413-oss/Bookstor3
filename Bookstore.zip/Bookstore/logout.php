<?php
// ==========================================
// logout.php - Keluar/logout
// ==========================================
// Pakai init.php supaya yang dihapus adalah session user (BOOKSTORE_USER).
// Sebelumnya cuma session_start() polos, jadi yang dibuka session lain dan
// login user TIDAK ikut terhapus (logout seolah tidak berfungsi).
require_once 'includes/init.php';

$_SESSION = [];   // kosongkan data session (user_id, nama, role)
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

header("Location: index.php");
exit;
