<?php
// ==========================================
// includes/book_card.php - Kartu 1 buku (dipakai di Home, Genre, Search, Wishlist)
// Butuh variabel $book (1 baris dari sql_buku_statistik(), jadi ada rating_avg, rating_count, terjual)
// Opsional: $tag_kartu (teks label di pojok cover, mis. "Best seller" / "Trending")
// ==========================================
?>
<a href="book_detail.php?id=<?php echo (int)$book['id']; ?>" class="book-card">
    <div class="book-cover">
        <img src="<?php echo e(cover_url($book)); ?>" alt="<?php echo e($book['judul']); ?>" loading="lazy">
        <?php if (!empty($tag_kartu)) { ?><span class="book-tag"><?php echo e($tag_kartu); ?></span><?php } ?>
    </div>
    <p class="book-title"><?php echo e($book['judul']); ?></p>
    <?php if (!empty($book['penulis'])) { ?><p class="book-author"><?php echo e($book['penulis']); ?></p><?php } ?>
    <p class="book-rating">
        <?php if (!empty($book['rating_count'])) { ?>
            <?php echo bintang($book['rating_avg']); ?>
            <span><?php echo e(teks_rating($book['rating_avg'], $book['rating_count'])); ?></span>
        <?php } else { ?>
            <span class="book-rating-kosong">Belum ada rating</span>
        <?php } ?>
    </p>
    <p class="book-price"><?php echo rupiah($book['harga']); ?></p>
    <?php if (!empty($tag_kartu) && $tag_kartu === 'Best seller' && !empty($book['terjual'])) { ?>
        <p class="book-sold"><?php echo (int)$book['terjual']; ?> terjual</p>
    <?php } ?>
</a>
