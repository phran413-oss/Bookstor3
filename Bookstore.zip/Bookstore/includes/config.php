<?php
// ==========================================
// includes/config.php - Pengaturan koneksi database & upload
// ==========================================

$host   = "localhost";
$user   = "root";
$pass   = "";          // default XAMPP kosong
$dbname = "bookstore";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

// Batas ukuran gambar yang boleh diupload (cover buku & bukti pembayaran)
define('MAX_UPLOAD_BYTES', 2 * 1024 * 1024); // 2 MB
