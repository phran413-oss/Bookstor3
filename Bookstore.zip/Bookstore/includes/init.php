<?php
// ==========================================
// includes/init.php - Dipanggil PALING ATAS di setiap halaman
// Isinya: session, koneksi database, dan fungsi-fungsi bantu
// ==========================================

// Admin dan user pakai session TERPISAH (nama cookie beda), jadi bisa login
// bersamaan di 2 tab: admin di localhost/Bookstore/admin/, user di localhost/Bookstore/
if (basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin') {
    session_name('BOOKSTORE_ADMIN');
} else {
    session_name('BOOKSTORE_USER');
}
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';

// Pastikan akun yang tersimpan di session masih ada di database (lihat helpers.php)
validasi_sesi($conn);
