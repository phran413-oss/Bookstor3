<?php
// ==========================================
// includes/helpers.php - Fungsi-fungsi kecil yang dipakai banyak halaman
// ==========================================

// ---------- STATUS PESANAN ----------
// Alur: Menunggu Pembayaran -> Menunggu Verifikasi -> Diproses -> Selesai
//       (kalau bukti ditolak admin: Pembayaran Ditolak -> user upload ulang)
//       (kalau user batal sebelum bayar: Dibatalkan)
const STATUS_MENUNGGU_BAYAR  = 'Menunggu Pembayaran';
const STATUS_MENUNGGU_VERIF  = 'Menunggu Verifikasi';
const STATUS_DITOLAK         = 'Pembayaran Ditolak';
const STATUS_DIPROSES        = 'Diproses';
const STATUS_SELESAI         = 'Selesai';
const STATUS_DIBATALKAN      = 'Dibatalkan';

// Prefix URL buat link/asset: '' kalau file ada di folder utama, '../' kalau di admin/
define('BASE', basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin' ? '../' : '');

// ---------- OUTPUT ----------

// Escape teks sebelum ditampilkan di HTML (cegah XSS). Pakai ini buat SEMUA data dari database/user.
function e($teks)
{
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}

function rupiah($angka)
{
    return 'Rp' . number_format((float)$angka, 0, ',', '.');
}

function tanggal($waktu, $format = 'd M Y, H:i')
{
    return date($format, strtotime($waktu));
}

function nomor_order($id)
{
    return '#' . str_pad($id, 6, '0', STR_PAD_LEFT);
}

// Label status dengan warna (class-nya ada di style.css)
function badge_status($status)
{
    $peta = [
        STATUS_MENUNGGU_BAYAR => ['status-pending', 'Menunggu Pembayaran'],
        STATUS_MENUNGGU_VERIF => ['status-info',    'Menunggu Verifikasi'],
        STATUS_DITOLAK        => ['status-danger',  'Pembayaran Ditolak'],
        STATUS_DIPROSES       => ['status-info',    'Diproses'],
        STATUS_SELESAI        => ['status-selesai', 'Selesai'],
        STATUS_DIBATALKAN     => ['status-danger',  'Dibatalkan'],
    ];
    // Data lama / status tak dikenal tetap tampil apa adanya
    list($kelas, $teks) = $peta[$status] ?? ['status-pending', $status];
    return '<span class="' . $kelas . '">' . e($teks) . '</span>';
}

// URL gambar cover buku (atau placeholder kalau belum ada cover)
function cover_url($book, $lebar = 150, $tinggi = 220)
{
    if (!empty($book['cover_image'])) {
        return BASE . 'assets/images/books/' . rawurlencode($book['cover_image']);
    }
    return 'https://placehold.co/' . $lebar . 'x' . $tinggi . '?text=' . urlencode($book['judul']);
}

// ---------- LOGIN / AKSES ----------

// Cocokkan session dengan database. Dipanggil otomatis dari init.php di SETIAP halaman.
// Kalau akun di session sudah tidak ada di tabel users (misal database di-import ulang atau
// user dihapus admin), session dibersihkan -> user dianggap belum login. Tanpa ini, INSERT ke
// cart/wishlist/orders/reviews gagal dengan error "foreign key constraint fails".
// Nama & role juga disegarkan dari database, jadi perubahan role langsung berlaku.
function validasi_sesi($conn)
{
    if (!isset($_SESSION['user_id'])) {
        return;
    }
    $stmt = mysqli_prepare($conn, "SELECT nama, role FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $akun = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$akun) {
        $_SESSION = [];
        return;
    }
    $_SESSION['nama'] = $akun['nama'];
    $_SESSION['role'] = $akun['role'];
}

function wajib_login()
{
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . BASE . "login.php");
        exit;
    }
}

function wajib_admin()
{
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
        header("Location: " . BASE . "admin/login.php");
        exit;
    }
}

// ---------- UPLOAD GAMBAR ----------

// Simpan gambar upload ke $folder dengan nama acak.
// Return nama file kalau sukses, atau NULL kalau gagal (pesan error ada di $error).
// Cek: harus beneran gambar (jpg/png/webp), maksimal MAX_UPLOAD_BYTES.
function simpan_gambar($file, $folder, &$error)
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "Upload gagal, coba lagi.";
        return null;
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        $error = "Ukuran file maksimal " . (MAX_UPLOAD_BYTES / 1024 / 1024) . " MB.";
        return null;
    }

    // Cek tipe file dari ISI file-nya (bukan dari nama/ekstensi yang bisa dipalsukan)
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $ekstensi_boleh = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

    if (!isset($ekstensi_boleh[$mime]) || @getimagesize($file['tmp_name']) === false) {
        $error = "File harus berupa gambar JPG, PNG, atau WEBP.";
        return null;
    }

    $nama_file = bin2hex(random_bytes(8)) . '.' . $ekstensi_boleh[$mime];

    if (!is_dir($folder)) {
        mkdir($folder, 0755, true);
    }
    if (!move_uploaded_file($file['tmp_name'], rtrim($folder, '/') . '/' . $nama_file)) {
        $error = "Gagal menyimpan file.";
        return null;
    }
    return $nama_file;
}

// ---------- DATA ----------

// Isi keranjang 1 user (JOIN cart + books), tiap item sudah dihitung subtotal-nya.
// Dipakai di cart.php dan checkout.php (sebelumnya query yang sama ditulis 2x).
function ambil_isi_cart($conn, $user_id)
{
    $stmt = mysqli_prepare($conn, "
        SELECT cart.id AS cart_id, cart.jumlah, books.*
        FROM cart
        JOIN books ON cart.book_id = books.id
        WHERE cart.user_id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($item = mysqli_fetch_assoc($result)) {
        $item['subtotal'] = $item['harga'] * $item['jumlah'];
        $items[] = $item;
    }
    return $items;
}

// Ambil 1 order beserta item-itemnya. $user_id diisi kalau order harus milik user tertentu
// (halaman user); kosongkan (null) untuk admin.
function ambil_order($conn, $order_id, $user_id = null)
{
    $sql = "SELECT orders.*, users.nama AS nama_user, users.email AS email_user
            FROM orders JOIN users ON orders.user_id = users.id
            WHERE orders.id = ?";
    if ($user_id !== null) {
        $sql .= " AND orders.user_id = ?";
    }
    $stmt = mysqli_prepare($conn, $sql);
    if ($user_id !== null) {
        mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
    } else {
        mysqli_stmt_bind_param($stmt, "i", $order_id);
    }
    mysqli_stmt_execute($stmt);
    $order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$order) {
        return [null, []];
    }

    $stmt_items = mysqli_prepare($conn, "SELECT * FROM order_items WHERE order_id = ?");
    mysqli_stmt_bind_param($stmt_items, "i", $order_id);
    mysqli_stmt_execute($stmt_items);
    $result_items = mysqli_stmt_get_result($stmt_items);

    $items = [];
    while ($row = mysqli_fetch_assoc($result_items)) {
        $items[] = $row;
    }
    return [$order, $items];
}

// Kembalikan stok buku dari sebuah order (dipakai waktu order dibatalkan)
function kembalikan_stok($conn, $order_id)
{
    $stmt = mysqli_prepare($conn, "
        UPDATE books JOIN order_items ON order_items.book_id = books.id
        SET books.stok = books.stok + order_items.jumlah
        WHERE order_items.order_id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
}

// URL file bukti pembayaran (disimpan di folder uploads/bukti/)
function bukti_url($nama_file)
{
    return BASE . 'uploads/bukti/' . rawurlencode($nama_file);
}

// Hapus file bukti dari folder (dipakai waktu user upload ulang)
function hapus_file_bukti($nama_file)
{
    if ($nama_file) {
        $path = __DIR__ . '/../uploads/bukti/' . basename($nama_file);
        if (is_file($path)) {
            unlink($path);
        }
    }
}

// ---------- BUKTI PEMBAYARAN -> PDF TERKOMPRESI ----------

// Ubah gambar bukti transfer jadi 1 file PDF (A4) yang sudah dikompres, simpan di $folder.
// Gambar diperkecil (maks 1300px) lalu di-JPEG kualitas 70, jadi PDF biasanya jauh lebih kecil dari fotonya.
// Foto besar (misal 8 MB dari kamera HP) boleh diupload, ukurannya dikecilkan di sini.
// Nama file: bukti_000010_xxxxxxxx.pdf (gampang dicari di folder uploads/bukti/).
// Return nama file, atau NULL kalau gagal (pesan di $error). Butuh ekstensi GD (aktif di XAMPP).
function simpan_bukti_pdf($file, $folder, $order_id, &$error)
{
    // Tidak ada batas ukuran dari aplikasi: file besar tetap diterima lalu dikompres jadi kecil.
    // (Batas bawaan PHP upload_max_filesize di php.ini tetap berlaku; di XAMPP defaultnya 40 MB.)
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        $error = "File terlalu besar untuk server (batas php.ini terlampaui).";
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "Upload gagal, coba lagi.";
        return null;
    }

    // Cek tipe dari ISI file, bukan dari ekstensinya
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $ukuran = @getimagesize($file['tmp_name']);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp']) || $ukuran === false) {
        $error = "File harus berupa gambar JPG, PNG, atau WEBP.";
        return null;
    }
    if ($ukuran[0] * $ukuran[1] > 40000000) {   // jaga memori server
        $error = "Resolusi gambar terlalu besar.";
        return null;
    }

    // Ekstensi GD (buat kompres gambar) belum aktif di php.ini -> jangan crash
    if (!function_exists('imagecreatefromstring')) {
        // Cadangan: JPEG bisa langsung dimasukkan ke PDF (tanpa dikompres)
        if ($mime == 'image/jpeg' && in_array($ukuran['channels'] ?? 3, [1, 3])) {
            $pdf = bangun_pdf_gambar(file_get_contents($file['tmp_name']), $ukuran[0], $ukuran[1], ($ukuran['channels'] ?? 3) == 1 ? 'DeviceGray' : 'DeviceRGB');
            return tulis_pdf_bukti($pdf, $folder, $order_id, $error);
        }
        // Cadangan PNG: decode manual (butuh zlib, aktif bawaan PHP) lalu masukkan ke PDF
        if ($mime == 'image/png' && $ukuran[0] * $ukuran[1] <= 12000000) {
            $w = 0;
            $h = 0;
            $rgb = png_ke_rgb(file_get_contents($file['tmp_name']), $w, $h);
            if ($rgb !== null) {
                $pdf = bangun_pdf_gambar(gzcompress($rgb, 6), $w, $h, 'DeviceRGB', 'FlateDecode');
                return tulis_pdf_bukti($pdf, $folder, $order_id, $error);
            }
        }
        $error = "Gambar belum bisa diproses. Coba upload ulang (pastikan JavaScript aktif) atau gunakan format JPG. Admin: aktifkan extension=gd di php.ini lalu restart Apache.";
        return null;
    }

    $asli = @imagecreatefromstring(file_get_contents($file['tmp_name']));
    if (!$asli) {
        $error = "Gambar tidak bisa dibaca.";
        return null;
    }

    // Perkecil kalau lebih besar dari 1300px, latar putih (PNG transparan jadi putih)
    $lebar = imagesx($asli);
    $tinggi = imagesy($asli);
    $skala = min(1, 1300 / max($lebar, $tinggi));
    $w = max(1, (int)round($lebar * $skala));
    $h = max(1, (int)round($tinggi * $skala));

    $kanvas = imagecreatetruecolor($w, $h);
    imagefill($kanvas, 0, 0, imagecolorallocate($kanvas, 255, 255, 255));
    imagecopyresampled($kanvas, $asli, 0, 0, 0, 0, $w, $h, $lebar, $tinggi);

    ob_start();
    imagejpeg($kanvas, null, 70);   // kualitas 70 = ukuran kecil, teks bukti masih jelas
    $jpeg = ob_get_clean();

    $pdf = bangun_pdf_gambar($jpeg, $w, $h);

    return tulis_pdf_bukti($pdf, $folder, $order_id, $error);
}

// Simpan isi PDF ke folder bukti, return nama file (atau NULL kalau gagal)
function tulis_pdf_bukti($pdf, $folder, $order_id, &$error)
{
    if (!is_dir($folder)) {
        mkdir($folder, 0755, true);
    }
    $nama_file = 'bukti_' . str_pad($order_id, 6, '0', STR_PAD_LEFT) . '_' . bin2hex(random_bytes(4)) . '.pdf';
    if (file_put_contents(rtrim($folder, '/') . '/' . $nama_file, $pdf) === false) {
        $error = "Gagal menyimpan file.";
        return null;
    }
    return $nama_file;
}

// Decode PNG (8-bit, tidak interlaced) jadi data RGB mentah tanpa ekstensi GD. Return NULL kalau tidak didukung.
function png_ke_rgb($data, &$w, &$h)
{
    if (substr($data, 0, 8) !== "\x89PNG\r\n\x1a\n") {
        return null;
    }
    $pos = 8;
    $n = strlen($data);
    $idat = '';
    $plte = '';
    $ihdr = null;
    while ($pos + 8 <= $n) {
        $len = unpack('N', substr($data, $pos, 4))[1];
        $tipe = substr($data, $pos + 4, 4);
        $isi = substr($data, $pos + 8, $len);
        if ($tipe === 'IHDR') {
            $ihdr = unpack('Nw/Nh/Cdepth/Ctype/Ccomp/Cfilter/Cinter', $isi);
        } elseif ($tipe === 'PLTE') {
            $plte = $isi;
        } elseif ($tipe === 'IDAT') {
            $idat .= $isi;
        } elseif ($tipe === 'IEND') {
            break;
        }
        $pos += 12 + $len;
    }
    if (!$ihdr || $ihdr['depth'] != 8 || $ihdr['inter'] != 0) {
        return null;
    }
    $kanal = [0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4][$ihdr['type']] ?? 0;
    if (!$kanal || ($ihdr['type'] == 3 && $plte === '')) {
        return null;
    }
    $w = $ihdr['w'];
    $h = $ihdr['h'];
    $raw = @gzuncompress($idat);
    $stride = $w * $kanal;
    if ($raw === false || strlen($raw) < ($stride + 1) * $h) {
        return null;
    }

    $prev = array_fill(0, $stride, 0);
    $out = [];
    for ($y = 0; $y < $h; $y++) {
        $off = $y * ($stride + 1);
        $f = ord($raw[$off]);
        $line = array_values(unpack('C*', substr($raw, $off + 1, $stride)));
        for ($i = 0; $i < $stride; $i++) {
            $a = $i >= $kanal ? $line[$i - $kanal] : 0;
            $b = $prev[$i];
            $c = $i >= $kanal ? $prev[$i - $kanal] : 0;
            if ($f == 1) {
                $line[$i] = ($line[$i] + $a) & 255;
            } elseif ($f == 2) {
                $line[$i] = ($line[$i] + $b) & 255;
            } elseif ($f == 3) {
                $line[$i] = ($line[$i] + (($a + $b) >> 1)) & 255;
            } elseif ($f == 4) {
                $p = $a + $b - $c;
                $pa = abs($p - $a);
                $pb = abs($p - $b);
                $pc = abs($p - $c);
                $pr = ($pa <= $pb && $pa <= $pc) ? $a : (($pb <= $pc) ? $b : $c);
                $line[$i] = ($line[$i] + $pr) & 255;
            }
        }
        $prev = $line;

        // Ubah baris jadi RGB (alpha dicampur ke latar putih)
        $baris = [];
        for ($x = 0; $x < $w; $x++) {
            $j = $x * $kanal;
            if ($ihdr['type'] == 2) {
                array_push($baris, $line[$j], $line[$j + 1], $line[$j + 2]);
            } elseif ($ihdr['type'] == 0) {
                array_push($baris, $line[$j], $line[$j], $line[$j]);
            } elseif ($ihdr['type'] == 3) {
                $k = $line[$j] * 3;
                array_push($baris, ord($plte[$k] ?? "\0"), ord($plte[$k + 1] ?? "\0"), ord($plte[$k + 2] ?? "\0"));
            } elseif ($ihdr['type'] == 4) {
                $al = $line[$j + 1];
                $v = (int)(($line[$j] * $al + 255 * (255 - $al)) / 255);
                array_push($baris, $v, $v, $v);
            } else {
                $al = $line[$j + 3];
                array_push(
                    $baris,
                    (int)(($line[$j] * $al + 255 * (255 - $al)) / 255),
                    (int)(($line[$j + 1] * $al + 255 * (255 - $al)) / 255),
                    (int)(($line[$j + 2] * $al + 255 * (255 - $al)) / 255)
                );
            }
        }
        $out[] = pack('C*', ...$baris);
    }
    return implode('', $out);
}

// Bikin PDF 1 halaman A4 berisi 1 gambar JPEG (tanpa library tambahan).
function bangun_pdf_gambar($jpeg, $w, $h, $warna = 'DeviceRGB', $filter = 'DCTDecode')
{
    $A4_W = 595.28;
    $A4_H = 841.89;
    $margin = 36;

    // Muat gambar ke halaman, di tengah, proporsi tetap
    $s = min(($A4_W - 2 * $margin) / $w, ($A4_H - 2 * $margin) / $h);
    $pw = $w * $s;
    $ph = $h * $s;
    $x = ($A4_W - $pw) / 2;
    $y = ($A4_H - $ph) / 2;
    $isi = sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /Im0 Do Q", $pw, $ph, $x, $y);

    $obj = [];
    $obj[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    $obj[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
    $obj[3] = sprintf("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>", $A4_W, $A4_H);
    $obj[4] = "<< /Length " . strlen($isi) . " >>\nstream\n" . $isi . "\nendstream";
    $obj[5] = "<< /Type /XObject /Subtype /Image /Width $w /Height $h /ColorSpace /$warna /BitsPerComponent 8 /Filter /$filter /Length " . strlen($jpeg) . " >>\nstream\n" . $jpeg . "\nendstream";

    $out = "%PDF-1.4\n";
    $offset = [];
    foreach ($obj as $no => $isi_obj) {
        $offset[$no] = strlen($out);
        $out .= "$no 0 obj\n$isi_obj\nendobj\n";
    }
    $xref = strlen($out);
    $out .= "xref\n0 " . (count($obj) + 1) . "\n0000000000 65535 f \n";
    foreach ($offset as $o) {
        $out .= sprintf("%010d 00000 n \n", $o);
    }
    $out .= "trailer\n<< /Size " . (count($obj) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";
    return $out;
}

// Tampilkan bukti di halaman: PDF -> pratinjau + tombol buka/unduh, gambar lama -> <img>
function tampil_bukti($nama_file, $tinggi = 420)
{
    $url = e(bukti_url($nama_file));
    if (strtolower(pathinfo($nama_file, PATHINFO_EXTENSION)) === 'pdf') {
        echo '<embed src="' . $url . '#toolbar=0" type="application/pdf" class="bukti-pdf" style="height:' . (int)$tinggi . 'px;">';
        echo '<p class="form-hint"><a href="' . $url . '" target="_blank">Buka PDF</a> | <a href="' . $url . '" download>Unduh</a></p>';
    } else {
        echo '<a href="' . $url . '" target="_blank"><img src="' . $url . '" alt="Bukti pembayaran" class="bukti-img"></a>';
    }
}

// ---------- RATING & BEST SELLER ----------

// Jumlah buku di section "Best seller" & "Trending now" di Home
const JUMLAH_RAK_HOME = 8;
// Bobot rating "trending" (lihat ambil_trending): makin besar, makin banyak ulasan yang dibutuhkan
// supaya rating sebuah buku dipercaya. 1 ulasan bintang 5 tidak langsung ngalahin buku
// yang punya banyak ulasan bintang 4,8.
const BOBOT_RATING_TRENDING = 3;

// Pesanan yang pembayarannya sudah diverifikasi admin dihitung sebagai "terjual".
// (Menunggu Pembayaran / Ditolak / Dibatalkan tidak dihitung.)
function sql_buku_statistik()
{
    return "
        SELECT books.*,
               COALESCE(r.rata, 0)   AS rating_avg,
               COALESCE(r.jumlah, 0) AS rating_count,
               COALESCE(s.terjual, 0) AS terjual
        FROM books
        LEFT JOIN (
            SELECT book_id, AVG(rating) AS rata, COUNT(*) AS jumlah
            FROM reviews GROUP BY book_id
        ) r ON r.book_id = books.id
        LEFT JOIN (
            SELECT order_items.book_id, SUM(order_items.jumlah) AS terjual
            FROM order_items
            JOIN orders ON orders.id = order_items.order_id
            WHERE orders.status IN ('" . STATUS_DIPROSES . "', '" . STATUS_SELESAI . "')
            GROUP BY order_items.book_id
        ) s ON s.book_id = books.id
    ";
}

// Best seller = buku yang paling banyak dibeli (jumlah eksemplar, bukan jumlah pesanan)
function ambil_best_seller($conn, $limit = JUMLAH_RAK_HOME)
{
    $limit = max(1, (int)$limit);
    return mysqli_query($conn, sql_buku_statistik() . "
        WHERE s.terjual > 0
        ORDER BY s.terjual DESC, rating_avg DESC, books.id ASC
        LIMIT $limit");
}

// Trending now = rating tertinggi. Pakai rata-rata berbobot (cara IMDb):
//   skor = (v / (v + m)) * R  +  (m / (v + m)) * C
//   R = rata-rata rating buku, v = jumlah ulasannya, m = BOBOT_RATING_TRENDING,
//   C = rata-rata rating semua buku.
// Buku dengan sedikit ulasan "ditarik" mendekati rata-rata toko.
function ambil_trending($conn, $limit = JUMLAH_RAK_HOME)
{
    $limit = max(1, (int)$limit);
    $m = (float)BOBOT_RATING_TRENDING;
    $rata_semua = (float)(mysqli_fetch_row(mysqli_query($conn, "SELECT AVG(rating) FROM reviews"))[0] ?? 0);
    $skor = "((r.jumlah / (r.jumlah + $m)) * r.rata + ($m / (r.jumlah + $m)) * $rata_semua)";

    return mysqli_query($conn, sql_buku_statistik() . "
        WHERE r.jumlah > 0
        ORDER BY $skor DESC, r.jumlah DESC, books.id ASC
        LIMIT $limit");
}

// Bintang read-only. $rata 0-5 (boleh desimal, bintangnya terisi sebagian).
function bintang($rata)
{
    $rata = max(0, min(5, (float)$rata));
    $persen = round($rata / 5 * 100, 1);
    return '<span class="stars" style="--isi:' . $persen . '%" role="img" aria-label="Rating '
        . number_format($rata, 1, ',', '.') . ' dari 5"></span>';
}

// "4,5 (12)" atau "Belum ada rating"
function teks_rating($rata, $jumlah)
{
    if ((int)$jumlah == 0) {
        return 'Belum ada rating';
    }
    return number_format((float)$rata, 1, ',', '.') . ' (' . (int)$jumlah . ')';
}

// User boleh kasih rating kalau pernah beli buku ini DAN pesanannya sudah Selesai
function boleh_review($conn, $user_id, $book_id)
{
    $selesai = STATUS_SELESAI;
    $stmt = mysqli_prepare($conn, "
        SELECT 1 FROM order_items
        JOIN orders ON orders.id = order_items.order_id
        WHERE orders.user_id = ? AND order_items.book_id = ? AND orders.status = ?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "iis", $user_id, $book_id, $selesai);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    return mysqli_stmt_num_rows($stmt) > 0;
}
