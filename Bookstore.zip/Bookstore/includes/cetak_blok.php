<?php
// ==========================================
// includes/cetak_blok.php - Blok LABEL PENGIRIMAN & STRUK untuk admin.
// Dipakai di admin/transaksi_detail.php (pratinjau) dan admin/cetak.php (halaman cetak),
// jadi tampilan di layar = hasil cetaknya.
// ==========================================

// CSS untuk label & struk (cukup dipanggil sekali per halaman)
function css_cetak()
{
    ?>
<style>
.cetak-grid { display: flex; gap: 24px; flex-wrap: wrap; align-items: flex-start; }
.cetak-item { flex: 1 1 320px; min-width: 280px; }
.cetak-item h3 { font-size: 14px; margin: 0 0 8px; color: #444; }
.cetak-aksi { margin-top: 10px; }
.cetak-aksi a { text-decoration: none; display: inline-block; }

.lbl-box { background: #fff; border: 2px solid #000; padding: 14px 16px; font-family: Arial, Helvetica, sans-serif; font-size: 13px; line-height: 1.5; color: #000; max-width: 400px; }
.lbl-box .lbl-judul { font-weight: bold; font-size: 14px; border-bottom: 2px solid #000; padding-bottom: 6px; margin-bottom: 8px; }
.lbl-box .lbl-penerima { font-size: 16px; font-weight: bold; }
.lbl-box .lbl-alamat { white-space: pre-line; margin: 2px 0 8px; }
.lbl-box ul { margin: 2px 0 8px 18px; padding: 0; }
.lbl-box .lbl-order { border-top: 1px dashed #000; padding-top: 6px; font-weight: bold; }

.strk-box { background: #fff; width: 300px; max-width: 100%; padding: 14px; font-family: 'Courier New', Courier, monospace; font-size: 12px; color: #000; border: 1px dashed #999; }
.strk-box .tengah { text-align: center; }
.strk-box .toko { font-weight: bold; font-size: 15px; }
.strk-box .kecil { font-size: 11px; color: #444; line-height: 1.4; }
.strk-box .garis { border-top: 1px dashed #000; margin: 9px 0; }
.strk-box .baris { display: flex; justify-content: space-between; gap: 8px; margin-bottom: 3px; }
.strk-box .total { font-weight: bold; font-size: 14px; }
.strk-box .nama-item { margin-top: 5px; }
.strk-box .lunas { font-weight: bold; letter-spacing: 1px; }
</style>
<?php
}

// Label pengiriman (untuk ditempel di paket)
function blok_label($order, $items)
{
    ?>
    <div class="lbl-box">
        <div class="lbl-judul">📦 LABEL PENGIRIMAN</div>
        <div>Penerima:</div>
        <div class="lbl-penerima"><?php echo e($order['nama_user']); ?></div>
        <div style="margin-top:6px;">Alamat:</div>
        <div class="lbl-alamat"><?php echo e($order['alamat_pengiriman']); ?></div>
        <div>Isi Paket:</div>
        <ul>
            <?php foreach ($items as $item) { ?>
                <li><?php echo e($item['judul']); ?> (x<?php echo (int)$item['jumlah']; ?>)</li>
            <?php } ?>
        </ul>
        <div class="lbl-order">No. Order: <?php echo e(nomor_order($order['id'])); ?></div>
    </div>
    <?php
}

// Struk (arsip admin). Status LUNAS kalau pembayaran sudah diterima.
function blok_struk($order, $items)
{
    $lunas = in_array($order['status'], [STATUS_DIPROSES, STATUS_SELESAI]);
    ?>
    <div class="strk-box">
        <div class="tengah">
            <div class="toko">📚 BOOKSTORE</div>
            <div class="kecil">Jl. Pelajar Indonesia No. 45, Kebayoran Baru<br>Jakarta Selatan, 12190</div>
            <div style="font-weight:bold; margin-top:8px;">STRUK PEMBELIAN</div>
        </div>
        <div class="garis"></div>
        <div class="baris"><span>No. Order</span><span><?php echo e(nomor_order($order['id'])); ?></span></div>
        <div class="baris"><span>Tgl Pesan</span><span><?php echo e(tanggal($order['created_at'], 'd-m-Y H:i')); ?></span></div>
        <?php if ($order['waktu_bayar']) { ?>
            <div class="baris"><span>Tgl Bayar</span><span><?php echo e(tanggal($order['waktu_bayar'], 'd-m-Y H:i')); ?></span></div>
        <?php } ?>
        <div class="baris"><span>Pembeli</span><span><?php echo e($order['nama_user']); ?></span></div>
        <div class="baris"><span>Metode</span><span><?php echo e($order['metode_pembayaran']); ?></span></div>
        <div class="garis"></div>
        <?php foreach ($items as $item) { ?>
            <div class="nama-item"><?php echo e($item['judul']); ?></div>
            <div class="baris" style="color:#444;">
                <span><?php echo (int)$item['jumlah']; ?> x <?php echo number_format($item['harga'], 0, ',', '.'); ?></span>
                <span><?php echo number_format($item['subtotal'], 0, ',', '.'); ?></span>
            </div>
        <?php } ?>
        <div class="garis"></div>
        <div class="baris total"><span>TOTAL</span><span><?php echo number_format($order['total_harga'], 0, ',', '.'); ?></span></div>
        <div class="garis"></div>
        <div class="tengah">Status Pembayaran: <span class="lunas"><?php echo $lunas ? 'LUNAS' : 'BELUM LUNAS'; ?></span></div>
        <div class="tengah">Status Pesanan: <strong><?php echo e($order['status']); ?></strong></div>
        <div class="tengah kecil" style="margin-top:10px;">** Terima kasih sudah belanja di Bookstore **</div>
    </div>
    <?php
}
