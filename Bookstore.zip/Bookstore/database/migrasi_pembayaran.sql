-- ==========================================================
-- Migrasi untuk database `bookstore` yang SUDAH ADA
-- (kalau install baru, cukup import bookstore.sql saja)
--
-- Cara pakai: phpMyAdmin -> pilih database `bookstore` -> tab SQL -> paste -> Go
-- Sebaiknya export/backup database dulu.
-- ==========================================================

-- 1. Kolom baru buat bukti pembayaran
ALTER TABLE `orders`
  MODIFY `status` varchar(25) NOT NULL DEFAULT 'Menunggu Pembayaran',
  ADD COLUMN `bukti_pembayaran` varchar(255) DEFAULT NULL AFTER `status`,
  ADD COLUMN `waktu_bayar` datetime DEFAULT NULL AFTER `bukti_pembayaran`,
  ADD COLUMN `catatan_admin` varchar(255) DEFAULT NULL AFTER `waktu_bayar`;

-- 2. Hapus PPN dari pesanan lama: total = jumlah subtotal item
UPDATE `orders`
SET `total_harga` = (SELECT COALESCE(SUM(`subtotal`), 0) FROM `order_items` WHERE `order_items`.`order_id` = `orders`.`id`);

-- 3. Samakan status lama dengan alur baru
UPDATE `orders` SET `status` = 'Selesai'             WHERE `status` IN ('Berhasil', 'Selesai');
UPDATE `orders` SET `status` = 'Menunggu Pembayaran' WHERE `status` = 'Menunggu Diproses';
