-- ==========================================================
-- Migrasi fitur Rating/Ulasan untuk database `bookstore` yang SUDAH ADA
-- (kalau install baru, cukup import bookstore.sql saja)
--
-- Cara pakai: phpMyAdmin -> pilih database `bookstore` -> tab SQL -> paste -> Go
-- Sebaiknya export/backup database dulu.
-- ==========================================================

-- 1. Tabel rating + ulasan (1 user = 1 ulasan per buku)
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `komentar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_book` (`user_id`,`book_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. "Best seller" sekarang dihitung otomatis dari jumlah buku terjual, dan
--    "Trending now" dari rating tertinggi, jadi flag manual tidak dipakai lagi.
ALTER TABLE `books`
  DROP COLUMN `is_bestseller`,
  DROP COLUMN `is_trending`;
