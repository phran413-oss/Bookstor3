-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Versi tanpa PPN + alur bukti pembayaran + rating/ulasan
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `penulis` varchar(100) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `stok` int(11) DEFAULT 0,
  `category_id` int(11) DEFAULT NULL,
  `is_new` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `judul`, `penulis`, `harga`, `cover_image`, `deskripsi`, `stok`, `category_id`, `is_new`, `created_at`) VALUES
(1, 'Goodbye, Eri', 'Anonymous', 47000.00, '1785325271_images.jpg', '', 45, 3, 0, '2026-07-24 13:21:13'),
(2, 'Sapiens', 'Yuval Noah Harari', 112000.00, '1785325158_download.png', '', 50, 6, 0, '2026-07-24 13:21:13'),
(3, 'Atomic Habits', 'James Clear', 65000.00, '1785325078_AtomicHabits.jpg', '', 49, 5, 0, '2026-07-24 13:21:13'),
(4, 'The Little Prince', 'Antoine de Saint-Exupery', 47000.00, '1785311272_SiPangeranKecil.jpg', '', 49, 3, 0, '2026-07-24 13:21:13'),
(5, 'The Psychology of Money', 'Morgan Housel', 80000.00, '1785329636_images (1).jpg', 'Mengulas 19 cerita pendek tentang cara unik manusia berpikir, bersikap, dan mengambil keputusan terkait uang dan kekayaan.', 49, 7, 0, '2026-07-29 12:53:56'),
(6, 'Filosofi Teras', 'Henry Manampiring', 90000.00, '1785329810_images (2).jpg', 'Penerapan stoisisme (filsafat Yunani-Romawi kuno) yang dikemas secara relevan dan santai untuk membantu mengatasi kecemasan hidup modern.', 48, 6, 0, '2026-07-29 12:56:50'),
(7, 'Keajaiban Toko Kelontong Namiya', 'Keigo Higashino', 85000.00, '1785330035_download.jpg', 'Tiga pencuri bersembunyi di toko kelontong tua dan menemukan surat-surat dari masa lalu yang meminta nasihat kehidupan secara misterius.', 49, 5, 0, '2026-07-29 13:00:35');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `jumlah` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `book_id`, `jumlah`, `created_at`) VALUES
(4, 4, 7, 1, '2026-07-30 12:29:01');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nama_kategori`, `parent_id`) VALUES
(1, 'Fiksi', NULL),
(2, 'Non-Fiksi', NULL),
(3, 'Romansa Kontemporer', 1),
(4, 'Fantasy Romance', 1),
(5, 'Misteri dan Detektif', 1),
(6, 'Pengembangan Diri', 2),
(7, 'Psikologi Populer', 2),
(8, 'Biografi dan Otobiografi', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_harga` decimal(12,2) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `alamat_pengiriman` text DEFAULT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Menunggu Pembayaran',
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `waktu_bayar` datetime DEFAULT NULL,
  `catatan_admin` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_harga`, `metode_pembayaran`, `alamat_pengiriman`, `status`, `bukti_pembayaran`, `waktu_bayar`, `catatan_admin`, `created_at`) VALUES
(1, 3, 159000.00, 'GoPay', NULL, 'Selesai', NULL, NULL, NULL, '2026-07-30 03:36:20'),
(2, 3, 80000.00, 'DANA', NULL, 'Selesai', NULL, NULL, NULL, '2026-07-31 01:16:56'),
(3, 3, 85000.00, 'GoPay', 'Jl.amal 1, 1B, RT 11, RW 01, PONDOK BAMBU, DUREN SAWIT, JAKARTA', 'Selesai', NULL, NULL, NULL, '2026-07-31 10:41:32'),
(4, 3, 47000.00, 'DANA', 'rumh4no,jln amal rt 1 rw 5', 'Selesai', NULL, NULL, NULL, '2026-07-31 10:59:53'),
(5, 3, 47000.00, 'QRIS', 'Jl.Amal 1, RT 11, RW 01, NO 1B, PONDOK BAMBU, DUREN SAWIT, JAKARTA', 'Selesai', NULL, NULL, NULL, '2026-07-31 11:29:12'),
(6, 3, 90000.00, 'QRIS', 'A', 'Selesai', NULL, NULL, NULL, '2026-08-01 01:57:42'),
(7, 3, 47000.00, 'GoPay', 'a', 'Selesai', NULL, NULL, NULL, '2026-08-06 04:47:19'),
(8, 1, 47000.00, 'QRIS', 'jl amal', 'Selesai', NULL, NULL, NULL, '2026-09-24 00:03:29'),
(9, 5, 90000.00, 'QRIS', 'jl.semok memek', 'Menunggu Pembayaran', NULL, NULL, NULL, '2026-11-03 01:51:36');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `judul` varchar(150) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `book_id`, `judul`, `harga`, `jumlah`, `subtotal`) VALUES
(1, 1, 1, 'Goodbye, Eri', 47000.00, 1, 47000.00),
(2, 1, 3, 'Atomic Habits', 65000.00, 1, 65000.00),
(3, 1, 4, 'The Little Prince', 47000.00, 1, 47000.00),
(4, 2, 5, 'The Psychology of Money', 80000.00, 1, 80000.00),
(5, 3, 7, 'Keajaiban Toko Kelontong Namiya', 85000.00, 1, 85000.00),
(6, 4, 1, 'Goodbye, Eri', 47000.00, 1, 47000.00),
(7, 5, 1, 'Goodbye, Eri', 47000.00, 1, 47000.00),
(8, 6, 6, 'Filosofi Teras', 90000.00, 1, 90000.00),
(9, 7, 1, 'Goodbye, Eri', 47000.00, 1, 47000.00),
(10, 8, 1, 'Goodbye, Eri', 47000.00, 1, 47000.00),
(11, 9, 6, 'Filosofi Teras', 90000.00, 1, 90000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Admin Bookstore', 'admin@bookstore.com', '$2y$10$x6pz0GIAHOEPPAmEUmKTNuHvR292wAYP4U3fiX37OLb0zifSQGmhm', 'admin', '2026-07-24 13:21:13'),
(2, 'Budi Santoso', 'budi@mail.com', '$2y$10$YQ5Vec3vtFbgfkJMLVYI3OiDcbOtWOn04tgtj6e.87CU5PO59Inku', 'user', '2026-07-24 13:21:13'),
(3, 'Phran', 'phran413@gmail.com', '$2y$10$zc.Yj05zk/20B.VQhtAJYOVwYNnYKIrUoqDqhEy0IpmIGnK6bqNhe', 'admin', '2026-07-29 05:59:10'),
(4, 'malik', 'malikhitam2009@gmail.com', '$2y$10$CyFdUIkqgJfkWfn3lKdmT.Cweg2gqOwLQ3CGTC9sZKzXlKrhBsiR2', 'user', '2026-07-30 00:49:17'),
(5, 'tri', 'ridhotri150@gmail.com', '$2y$10$mFLNSmcq6pdFvWVLFHVmOOD2a0igDB5nKQPPyzGTFiUBqbaLKXRcu', 'user', '2026-11-03 01:49:48');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `book_id`, `created_at`) VALUES
(1, 4, 1, '2026-07-30 01:23:18'),
(2, 4, 2, '2026-07-30 01:25:12'),
(4, 3, 1, '2026-07-31 01:08:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_items_order` (`order_id`),
  ADD KEY `fk_order_items_book` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`book_id`),
  ADD KEY `book_id` (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;

--
-- Table structure for table `reviews` (rating 1-5 + ulasan; 1 user = 1 ulasan per buku)
-- Dipakai untuk section "Trending now" (rating tertinggi)
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `komentar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_book` (`user_id`,`book_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Contoh ulasan (dari pembeli yang pesanannya sudah Selesai)
--

INSERT INTO `reviews` (`user_id`, `book_id`, `rating`, `komentar`) VALUES
(3, 1, 5, 'Ceritanya bikin susah berhenti baca.'),
(1, 1, 4, 'Bagus, endingnya mengejutkan.'),
(3, 3, 4, 'Praktis dan mudah diterapkan.'),
(3, 4, 5, 'Klasik yang tidak pernah usang.'),
(3, 5, 4, 'Sudut pandang soal uang yang segar.'),
(3, 6, 5, 'Stoisisme jadi terasa dekat dengan keseharian.'),
(3, 7, 5, 'Alur ceritanya rapi dan menyentuh.');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
