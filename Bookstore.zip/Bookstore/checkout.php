<?php
// ==========================================
// checkout.php - Alamat + pilih metode pembayaran, lalu buat pesanan
// Setelah klik "Buat Pesanan" -> diarahkan ke pembayaran.php buat bayar & upload bukti
// ==========================================
require_once 'includes/init.php';
require_once 'includes/payment_methods.php';
wajib_login();

$user_id = $_SESSION['user_id'];
$error = "";

// Mode "Beli Sekarang": ?beli=ID -> checkout HANYA buku itu (1 buah), isi keranjang tidak ikut
$beli_id = (int)($_GET['beli'] ?? $_POST['beli'] ?? 0);

if ($beli_id > 0) {
    $stmt_beli = mysqli_prepare($conn, "SELECT * FROM books WHERE id = ?");
    mysqli_stmt_bind_param($stmt_beli, "i", $beli_id);
    mysqli_stmt_execute($stmt_beli);
    $buku_beli = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_beli));

    if (!$buku_beli) {
        header("Location: index.php");
        exit;
    }
    $buku_beli['jumlah'] = 1;
    $buku_beli['subtotal'] = $buku_beli['harga'];
    $items = [$buku_beli];
} else {
    // Mode biasa: checkout seluruh isi keranjang
    $items = ambil_isi_cart($conn, $user_id);
}
$total_harga = array_sum(array_column($items, 'subtotal'));

// Tidak ada yang bisa di-checkout (keranjang kosong)
if (count($items) == 0) {
    header("Location: cart.php");
    exit;
}

// ---------- PROSES CHECKOUT ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $metode = $_POST['metode_pembayaran'] ?? '';
    $alamat = trim($_POST['alamat_pengiriman'] ?? '');

    if (!isset($METODE_PEMBAYARAN[$metode])) {
        $error = "Pilih metode pembayaran dulu.";
    } elseif ($alamat == '') {
        $error = "Alamat pengiriman wajib diisi.";
    } else {
        // Semua langkah di bawah dibungkus transaksi: kalau 1 gagal (misal stok kurang),
        // semuanya dibatalkan, jadi nggak ada pesanan "setengah jadi".
        mysqli_begin_transaction($conn);
        try {
            // 1. Buat pesanan baru (status awal: Menunggu Pembayaran)
            $status_awal = STATUS_MENUNGGU_BAYAR;
            $stmt_order = mysqli_prepare($conn, "INSERT INTO orders (user_id, total_harga, metode_pembayaran, alamat_pengiriman, status) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt_order, "idsss", $user_id, $total_harga, $metode, $alamat, $status_awal);
            mysqli_stmt_execute($stmt_order);
            $order_id = mysqli_insert_id($conn);

            foreach ($items as $item) {
                // 2. Kurangi stok. "AND stok >= ?" memastikan stok nggak jadi minus
                $stmt_stok = mysqli_prepare($conn, "UPDATE books SET stok = stok - ? WHERE id = ? AND stok >= ?");
                mysqli_stmt_bind_param($stmt_stok, "iii", $item['jumlah'], $item['id'], $item['jumlah']);
                mysqli_stmt_execute($stmt_stok);
                if (mysqli_stmt_affected_rows($stmt_stok) == 0) {
                    throw new Exception("Stok \"" . $item['judul'] . "\" tidak cukup.");
                }

                // 3. Simpan detail item (judul & harga disalin, biar struk lama tetap benar kalau buku diubah/dihapus)
                $stmt_item = mysqli_prepare($conn, "INSERT INTO order_items (order_id, book_id, judul, harga, jumlah, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt_item, "iisdid", $order_id, $item['id'], $item['judul'], $item['harga'], $item['jumlah'], $item['subtotal']);
                mysqli_stmt_execute($stmt_item);
            }

            // 4. Kosongkan cart (hanya untuk checkout biasa, "Beli Sekarang" tidak menyentuh keranjang)
            if ($beli_id == 0) {
                $stmt_kosong = mysqli_prepare($conn, "DELETE FROM cart WHERE user_id = ?");
                mysqli_stmt_bind_param($stmt_kosong, "i", $user_id);
                mysqli_stmt_execute($stmt_kosong);
            }

            mysqli_commit($conn);

            header("Location: pembayaran.php?order_id=" . $order_id);
            exit;

        } catch (Exception $ex) {
            mysqli_rollback($conn);
            $error = $ex->getMessage();
        }
    }
}

$judul_halaman = 'Checkout';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="checkout-section">
        <?php $langkah_aktif = 2; include 'includes/steps.php'; ?>
        <h2>Checkout</h2>

        <?php if ($error) { ?>
            <p class="auth-error"><?php echo e($error); ?></p>
        <?php } ?>

        <div class="checkout-layout">

            <!-- ===== KIRI: Ringkasan pesanan ===== -->
            <div class="checkout-summary">
                <h3>Ringkasan Pesanan</h3>
                <?php foreach ($items as $item) { ?>
                    <div class="checkout-item-row">
                        <span><?php echo e($item['judul']); ?> x<?php echo (int)$item['jumlah']; ?></span>
                        <span><?php echo rupiah($item['subtotal']); ?></span>
                    </div>
                <?php } ?>
                <div class="checkout-item-row checkout-total-row">
                    <strong>Total</strong>
                    <strong><?php echo rupiah($total_harga); ?></strong>
                </div>
            </div>

            <!-- ===== KANAN: Alamat + metode pembayaran ===== -->
            <div class="checkout-payment">
                <form method="POST" action="">
                    <?php if ($beli_id > 0) { ?>
                        <input type="hidden" name="beli" value="<?php echo $beli_id; ?>">
                    <?php } ?>
                    <h3>Alamat Pengiriman</h3>
                    <textarea name="alamat_pengiriman" rows="3" class="checkout-alamat" placeholder="Nama penerima, alamat lengkap, no HP..." required><?php echo e($_POST['alamat_pengiriman'] ?? ''); ?></textarea>

                    <h3>Metode Pembayaran</h3>
                    <?php foreach ($METODE_PEMBAYARAN as $kode => $metode) { ?>
                        <label class="payment-option">
                            <input type="radio" name="metode_pembayaran" value="<?php echo e($kode); ?>" required
                                <?php echo (($_POST['metode_pembayaran'] ?? '') == $kode) ? 'checked' : ''; ?>>
                            <span><?php echo e($metode['label']); ?></span>
                        </label>
                    <?php } ?>

                    <p class="form-hint">Setelah pesanan dibuat, kamu akan diarahkan ke halaman pembayaran untuk transfer dan upload bukti pembayaran.</p>

                    <button type="submit" class="btn-checkout">Buat Pesanan</button>
                </form>
            </div>

        </div>
    </section>

<?php include 'includes/footer.php'; ?>
