<?php
// ==========================================
// index.php - Halaman Home
// ==========================================
require_once 'includes/init.php';

// Semua section dihitung otomatis (tidak ada lagi centang manual di admin):
//  - What's new   : buku yang ditambahin dalam 7 hari terakhir
//  - Best seller  : buku yang paling banyak dibeli (pesanan sudah dibayar & diverifikasi)
//  - Trending now : buku dengan rating tertinggi dari ulasan pembeli
// Format: judul => [hasil query, label di cover]
$sections = [
    "What's new?"  => [mysqli_query($conn, sql_buku_statistik() . " WHERE books.created_at >= NOW() - INTERVAL 7 DAY ORDER BY books.created_at DESC"), null],
    "Best seller"  => [ambil_best_seller($conn), 'Best seller'],
    "Trending now" => [ambil_trending($conn), 'Trending'],
];

// Cover buat hiasan hero (3 buku, utamakan yang paling laris)
$hero_covers = [];
$q_hero = mysqli_query($conn, sql_buku_statistik() . " WHERE books.cover_image IS NOT NULL AND books.cover_image <> '' ORDER BY terjual DESC, books.id DESC LIMIT 3");
while ($b = mysqli_fetch_assoc($q_hero)) {
    $hero_covers[] = $b;
}

$judul_halaman = null;
include 'includes/header.php';
?>

    <section class="hero">
        <div class="hero-text">
            <span class="hero-eyebrow">Toko buku online</span>
            <h1>Temukan bacaan berikutnya yang <em>susah diletakkan.</em></h1>
            <p class="hero-sub">Dari fiksi sampai pengembangan diri, semua ada di satu rak. Pilih, bayar, dan buku sampai di rumahmu.</p>
            <div class="hero-cta">
                <a href="books.php" class="hero-btn primary">Jelajahi genre</a>
                <a href="#best-seller" class="hero-btn ghost">Lihat best seller</a>
            </div>
        </div>
        <?php if (count($hero_covers) > 0) { ?>
            <div class="hero-art" aria-hidden="true">
                <?php foreach ($hero_covers as $b) { ?>
                    <img src="<?php echo e(cover_url($b)); ?>" alt="">
                <?php } ?>
            </div>
        <?php } ?>
    </section>

    <?php foreach ($sections as $judul => [$result, $tag_kartu]) { ?>
        <section class="book-section" id="<?php echo e(trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($judul)), '-')); ?>">
            <h2><?php echo e($judul); ?></h2>
            <div class="book-wrapper">
                <div class="book-list">
                    <?php if (mysqli_num_rows($result) == 0) { ?>
                        <p class="shelf-empty"><?php
                        echo $tag_kartu === 'Best seller' ? 'Belum ada buku yang terjual.'
                           : ($tag_kartu === 'Trending' ? 'Belum ada buku yang diberi rating.' : 'Belum ada buku di rak ini.');
                    ?></p>
                    <?php } else {
                        while ($book = mysqli_fetch_assoc($result)) {
                            include 'includes/book_card.php';
                        }
                    } ?>
                </div>
            </div>
        </section>
    <?php } ?>

<?php unset($tag_kartu); include 'includes/footer.php'; ?>
