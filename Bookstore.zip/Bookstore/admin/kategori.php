<?php
// ==========================================
// admin/kategori.php - Kelola Kategori & Sub-Genre
// CRUD: CREATE (form tambah di atas) + READ (daftar di bawah)
// Edit dan hapus ada di file terpisah: edit_kategori.php dan hapus_kategori.php
// ==========================================

// Muat session, koneksi database ($conn), dan fungsi bantu (helpers)
require_once '../includes/init.php';

// Hanya admin yang boleh lanjut
wajib_admin();

// Tempat menyimpan pesan error; kosong = tidak ada error
$error = "";

// ---------- TAMBAH KATEGORI / SUB-GENRE (CREATE) ----------
// REQUEST_METHOD = 'POST' artinya form tambah baru saja dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // trim() membuang spasi di awal dan akhir nama
    $nama_kategori = trim($_POST['nama_kategori']);
    // Kosong = kategori utama (parent_id NULL); diisi = sub-genre dari kategori itu
    $parent_id = $_POST['parent_id'] == '' ? null : (int)$_POST['parent_id'];

    // Validasi: nama tidak boleh kosong
    if ($nama_kategori == '') {
        $error = "Nama kategori tidak boleh kosong.";
    } else {
        // Tambah baris baru ke tabel categories
        $stmt = mysqli_prepare($conn, "INSERT INTO categories (nama_kategori, parent_id) VALUES (?, ?)");
        // "si" = string (nama), integer (parent_id), urut sesuai tanda "?"
        mysqli_stmt_bind_param($stmt, "si", $nama_kategori, $parent_id);
        mysqli_stmt_execute($stmt);
        // Pindah ke halaman ini lagi (GET) supaya form tidak terkirim ulang kalau di-refresh
        header("Location: kategori.php");
        exit;
    }
}

// ---------- AMBIL SEMUA KATEGORI (READ) ----------
// Ambil semua kategori sekali, lalu kelompokkan di PHP (nggak perlu query per kategori)
$kategori_utama = [];   // daftar kategori utama (parent_id kosong)
$sub_genre = [];        // sub-genre dikelompokkan per induk: $sub_genre[id_induk][] = sub-genre
// Query tanpa input user, jadi boleh langsung mysqli_query (tanpa prepare)
$result = mysqli_query($conn, "SELECT * FROM categories ORDER BY nama_kategori");
// Baca hasil query satu baris demi satu sampai habis
while ($k = mysqli_fetch_assoc($result)) {
    if ($k['parent_id'] === null) {
        // Tidak punya induk -> kategori utama
        $kategori_utama[] = $k;
    } else {
        // Punya induk -> masukkan ke kelompok sub-genre milik induknya
        $sub_genre[$k['parent_id']][] = $k;
    }
}

// Judul tab browser, dipakai oleh admin_header.php
$judul_halaman = 'Kategori';
// Tampilkan bagian atas halaman admin (sidebar, dll.)
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Kelola Kategori & Sub-Genre</h2>

        <div class="kategori-form-box">
            <h3>Tambah Baru</h3>
            <!-- Pesan error hanya muncul kalau $error tidak kosong; e() mengamankan teksnya -->
            <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>

            <!-- Form tambah: dikirim ke halaman ini juga, diproses di bagian PHP paling atas -->
            <form method="POST" action="" class="admin-form kategori-inline-form">
                <!-- name="nama_kategori" = kunci yang dibaca lewat $_POST['nama_kategori'] -->
                <input type="text" name="nama_kategori" placeholder="Nama kategori/sub-genre" required>
                <select name="parent_id">
                    <!-- value kosong = jadikan kategori utama -->
                    <option value="">-- Jadikan Kategori Utama --</option>
                    <!-- Satu pilihan untuk setiap kategori utama yang ada -->
                    <?php foreach ($kategori_utama as $k) { ?>
                        <option value="<?php echo (int)$k['id']; ?>">Sub-genre dari: <?php echo e($k['nama_kategori']); ?></option>
                    <?php } ?>
                </select>
                <button type="submit">+ Tambah</button>
            </form>
            <p class="form-hint">
                Kosongkan pilihan "induk" kalau mau bikin kategori utama baru (setara Fiksi/Non-Fiksi).
                Pilih salah satu kalau mau bikin sub-genre di dalamnya.
            </p>
        </div>

        <!-- Satu kotak untuk setiap kategori utama -->
        <?php foreach ($kategori_utama as $main) { ?>
            <div class="kategori-group">
                <div class="kategori-group-header">
                    <h3>#<?php echo e($main['nama_kategori']); ?></h3>
                    <div class="kategori-actions">
                        <!-- Link ke edit_kategori.php membawa id lewat URL (?id=...) -->
                        <a href="edit_kategori.php?id=<?php echo (int)$main['id']; ?>" class="btn-edit">Edit</a>
                        <!-- onclick confirm(): munculkan pertanyaan; kalau dibatalkan, link tidak jalan -->
                        <a href="hapus_kategori.php?id=<?php echo (int)$main['id']; ?>"
                           class="btn-delete"
                           onclick="return confirm('Hapus kategori ini? Sub-genre di dalamnya akan jadi kategori utama.');">Hapus</a>
                    </div>
                </div>
                <ul class="kategori-sub-list">
                    <!-- Kalau kategori ini belum punya sub-genre, tampilkan pesan -->
                    <?php if (empty($sub_genre[$main['id']])) { ?>
                        <li class="kategori-empty">Belum ada sub-genre.</li>
                    <?php } else {
                        // Kalau ada, tampilkan satu baris untuk setiap sub-genre
                        foreach ($sub_genre[$main['id']] as $sub) { ?>
                            <li>
                                <span><?php echo e($sub['nama_kategori']); ?></span>
                                <div class="kategori-actions">
                                    <a href="edit_kategori.php?id=<?php echo (int)$sub['id']; ?>" class="btn-edit">Edit</a>
                                    <a href="hapus_kategori.php?id=<?php echo (int)$sub['id']; ?>"
                                       class="btn-delete"
                                       onclick="return confirm('Hapus sub-genre ini?');">Hapus</a>
                                </div>
                            </li>
                    <?php }
                    } ?>
                </ul>
            </div>
        <?php } ?>
    </section>

<!-- Tampilkan bagian bawah halaman admin dan tutup koneksi database -->
<?php include '../includes/admin_footer.php'; ?>
