<?php
// ==========================================
// admin/login.php - Login khusus admin
// Pakai session terpisah dari user (lihat includes/init.php)
// ==========================================
require_once '../includes/init.php';
require_once '../includes/icons.php';

// Kalau sudah login sebagai admin, langsung ke dashboard
if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') == 'admin') {
    header("Location: index.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = mysqli_prepare($conn, "SELECT id, nama, password, role FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // Pesan error sengaja disamakan supaya tidak membocorkan email mana yang admin
    if (!$user || $user['role'] != 'admin' || !password_verify($password, $user['password'])) {
        $error = "Email atau password admin salah.";
    } else {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['role'] = $user['role'];

        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin - Bookstore</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <section class="auth-section">
        <div class="auth-box">
            <p class="text-center mb-15">
                <span class="logo logo-center"><span class="logo-mark"><?php echo ikon('book', 18); ?></span> Bookstore <small>Admin</small></span>
            </p>
            <h2>Login Admin</h2>

            <?php if ($error) { ?>
                <p class="auth-error"><?php echo e($error); ?></p>
            <?php } ?>

            <form method="POST" action="">
                <label>Email</label>
                <input type="email" name="email" required autofocus>

                <label>Password</label>
                <input type="password" name="password" required>

                <button type="submit">Masuk</button>
            </form>

            <p class="auth-switch"><a href="../index.php">&larr; Kembali ke toko</a></p>
        </div>
    </section>
</body>
</html>
