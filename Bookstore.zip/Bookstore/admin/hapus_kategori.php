<?php
// ==========================================
// admin/hapus_kategori.php - Hapus kategori (lalu balik ke daftar)
// CRUD: DELETE
// Dibuka dari tombol "Hapus" di kategori.php, contoh URL: hapus_kategori.php?id=5
// ==========================================

// Muat session, koneksi database ($conn), dan fungsi bantu (helpers)
require_once '../includes/init.php';

// Hanya admin yang boleh lanjut; kalau bukan, otomatis diarahkan ke halaman login admin
wajib_admin();

// Ambil id kategori dari URL (?id=5). "(int)" memaksa jadi angka, "?? 0" = pakai 0 kalau id tidak ada
$id = (int)($_GET['id'] ?? 0);

// Catatan: di database, parent_id & books.category_id pakai "ON DELETE SET NULL".
// Hapus kategori utama -> sub-genre-nya TIDAK ikut terhapus, tapi jadi kategori utama.
// Hapus sub-genre -> buku di dalamnya tetap ada, hanya kehilangan kategorinya.

// 1. prepare: siapkan perintah SQL; tanda "?" adalah tempat id (data tidak ditempel langsung = aman dari SQL injection)
$stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ?");
// 2. bind_param: isi tanda "?" dengan $id; "i" artinya integer (angka bulat)
mysqli_stmt_bind_param($stmt, "i", $id);
// 3. execute: jalankan perintah, baris kategori itu terhapus
mysqli_stmt_execute($stmt);

// Setelah selesai, kembalikan admin ke daftar kategori
header("Location: kategori.php");
// Hentikan skrip di sini supaya tidak ada kode lain yang jalan setelah pindah halaman
exit;
