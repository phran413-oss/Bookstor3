<?php
// ==========================================
// admin/edit_kategori.php - Edit kategori / sub-genre
// CRUD: UPDATE
// Dibuka dari tombol "Edit" di kategori.php, contoh URL: edit_kategori.php?id=5
// ==========================================

// Muat session, koneksi database ($conn), dan fungsi bantu (helpers)
require_once '../includes/init.php';

// Hanya admin yang boleh lanjut
wajib_admin();

// Ambil id kategori dari URL, paksa jadi angka (kalau tidak ada, jadi 0)
$id = (int)($_GET['id'] ?? 0);
// Tempat menyimpan pesan error; kosong = tidak ada error
$error = "";

// ---------- AMBIL DATA KATEGORI YANG MAU DIEDIT ----------
// prepare -> bind_param -> execute (pola 3 langkah, sama seperti file lain)
$stmt = mysqli_prepare($conn, "SELECT * FROM categories WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
// Ambil hasilnya satu baris jadi array ($kategori['nama_kategori'], dst); false kalau id tidak ada
$kategori = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Kalau kategori dengan id itu tidak ada, hentikan dan tampilkan pesan
if (!$kategori) {
    die("Kategori tidak ditemukan. <a href='kategori.php'>Kembali</a>");
}

// ---------- PROSES FORM (saat tombol "Simpan Perubahan" diklik) ----------
// REQUEST_METHOD = 'POST' artinya form baru saja dikirim (bukan sekadar membuka halaman)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // trim() membuang spasi di awal dan akhir nama
    $nama_kategori = trim($_POST['nama_kategori']);
    // Kosong = kategori utama (NULL di database); diisi = jadi sub-genre dari kategori itu
    $parent_id = $_POST['parent_id'] == '' ? null : (int)$_POST['parent_id'];

    // Validasi: nama tidak boleh kosong
    if ($nama_kategori == '') {
        $error = "Nama kategori tidak boleh kosong.";
    } else {
        // Ubah nama dan induk kategori yang id-nya cocok
        $stmt = mysqli_prepare($conn, "UPDATE categories SET nama_kategori = ?, parent_id = ? WHERE id = ?");
        // "sii" = string (nama), integer (parent_id), integer (id), urut sesuai tanda "?"
        mysqli_stmt_bind_param($stmt, "sii", $nama_kategori, $parent_id, $id);
        mysqli_stmt_execute($stmt);
        // Berhasil -> kembali ke daftar kategori, lalu hentikan skrip
        header("Location: kategori.php");
        exit;
    }
}

// Pilihan "induk": kategori utama selain dirinya sendiri
// (id != ? supaya kategori tidak bisa jadi induk dirinya sendiri)
$stmt = mysqli_prepare($conn, "SELECT * FROM categories WHERE parent_id IS NULL AND id != ? ORDER BY nama_kategori");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
// Hasilnya (banyak baris) disimpan dulu, dibaca satu-satu di bagian HTML dengan while
$kategori_utama = mysqli_stmt_get_result($stmt);

// Judul tab browser, dipakai oleh admin_header.php
$judul_halaman = 'Edit Kategori';
// Tampilkan bagian atas halaman admin (sidebar, dll.)
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <!-- e() = htmlspecialchars: mengamankan teks sebelum ditampilkan -->
        <h2>Edit Kategori: <?php echo e($kategori['nama_kategori']); ?></h2>
        <!-- Pesan error hanya muncul kalau $error tidak kosong -->
        <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>

        <!-- method="POST" + action="" = kirim data ke halaman ini juga (diproses di bagian PHP atas) -->
        <form method="POST" action="" class="admin-form">
            <label>Nama Kategori</label>
            <!-- value=... mengisi kolom dengan nama lama; name="nama_kategori" = kunci di $_POST -->
            <input type="text" name="nama_kategori" value="<?php echo e($kategori['nama_kategori']); ?>" required>

            <label>Induk Kategori</label>
            <select name="parent_id">
                <!-- value kosong = jadikan kategori utama -->
                <option value="">-- Jadikan Kategori Utama --</option>
                <!-- Ulangi sampai semua baris kategori utama habis dibaca -->
                <?php while ($k = mysqli_fetch_assoc($kategori_utama)) { ?>
                    <!-- "selected" ditambahkan kalau ini induk kategori yang sedang diedit -->
                    <option value="<?php echo (int)$k['id']; ?>" <?php echo ($k['id'] == $kategori['parent_id']) ? 'selected' : ''; ?>>
                        Sub-genre dari: <?php echo e($k['nama_kategori']); ?>
                    </option>
                <?php } ?>
            </select>

            <button type="submit">Simpan Perubahan</button>
        </form>
    </section>

<!-- Tampilkan bagian bawah halaman admin dan tutup koneksi database -->
<?php include '../includes/admin_footer.php'; ?>
