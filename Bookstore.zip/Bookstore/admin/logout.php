<?php
// ==========================================
// admin/logout.php - Logout admin (tidak mengganggu login user di tab lain)
// ==========================================
require_once '../includes/init.php';

session_destroy();   // hanya menghapus session admin

header("Location: login.php");
exit;
