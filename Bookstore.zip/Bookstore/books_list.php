<?php
// ==========================================
// books_list.php - Daftar buku berdasarkan genre yang dipilih
// ==========================================
require_once 'includes/init.php';

$category_id = (int)($_GET['category'] ?? 0);

// Nama kategori buat judul halaman
$stmt_kat = mysqli_prepare($conn, "SELECT nama_kategori FROM categories WHERE id = ?");
mysqli_stmt_bind_param($stmt_kat, "i", $category_id);
mysqli_stmt_execute($stmt_kat);
$kategori = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_kat));

// Semua buku di kategori ini
$stmt = mysqli_prepare($conn, sql_buku_statistik() . " WHERE books.category_id = ?");
mysqli_stmt_bind_param($stmt, "i", $category_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$judul_halaman = $kategori ? $kategori['nama_kategori'] : 'Genre';
include 'includes/header.php';
?>

    <section class="book-section">
        <a href="books.php" class="back-link">&larr; Kembali ke daftar genre</a>
        <h2><?php echo $kategori ? e($kategori['nama_kategori']) : 'Genre tidak ditemukan'; ?></h2>

        <div class="book-wrapper">
            <div class="book-list book-grid">
                <?php if (mysqli_num_rows($result) == 0) { ?>
                    <p class="shelf-empty">Belum ada buku di genre ini.</p>
                <?php } else {
                    while ($book = mysqli_fetch_assoc($result)) {
                        include 'includes/book_card.php';
                    }
                } ?>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
