<?php
// ==========================================
// book_detail.php - Detail Buku
// ==========================================
require_once 'includes/init.php';

$id = (int)($_GET['id'] ?? 0);

// LEFT JOIN: buku tanpa kategori tetap bisa dibuka
$stmt = mysqli_prepare($conn, "
    SELECT b.*, categories.nama_kategori AS genre
    FROM (" . sql_buku_statistik() . ") b
    LEFT JOIN categories ON b.category_id = categories.id
    WHERE b.id = ?
");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$book = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$book) {
    http_response_code(404);
    die("Buku tidak ditemukan. <a href='index.php'>Kembali ke Home</a>");
}

$aksi = $_POST['action'] ?? '';

// Pesan hasil aksi wishlist/keranjang. Aksinya diproses lalu halaman di-redirect (pola
// Post/Redirect/Get), jadi kalau halaman di-refresh, "Tambah ke Keranjang" tidak terkirim ulang
// dan jumlahnya tidak nambah sendiri.
$info = is_string($_GET['info'] ?? null) ? $_GET['info'] : '';
$pesan_wishlist = [
    'wl_tambah' => 'Ditambahkan ke wishlist!',
    'wl_hapus'  => 'Dihapus dari wishlist.',
][$info] ?? "";
$pesan_cart = [
    'cart_ok' => 'Ditambahkan ke keranjang!',
][$info] ?? "";
$error_cart = [
    'stok_habis' => 'Maaf, stok buku ini sedang habis.',
    'stok_penuh' => 'Jumlah di keranjang sudah mencapai stok yang tersedia.',
][$info] ?? "";

// ---------- TOMBOL WISHLIST & KERANJANG (wajib login) ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && in_array($aksi, ['toggle_wishlist', 'add_to_cart'])) {
    wajib_login();
    $user_id = $_SESSION['user_id'];
    $hasil = '';

    if ($aksi == 'toggle_wishlist') {
        $cek = mysqli_prepare($conn, "SELECT id FROM wishlist WHERE user_id = ? AND book_id = ?");
        mysqli_stmt_bind_param($cek, "ii", $user_id, $id);
        mysqli_stmt_execute($cek);
        mysqli_stmt_store_result($cek);

        if (mysqli_stmt_num_rows($cek) > 0) {
            $q = mysqli_prepare($conn, "DELETE FROM wishlist WHERE user_id = ? AND book_id = ?");
            $hasil = 'wl_hapus';
        } else {
            $q = mysqli_prepare($conn, "INSERT INTO wishlist (user_id, book_id) VALUES (?, ?)");
            $hasil = 'wl_tambah';
        }
        mysqli_stmt_bind_param($q, "ii", $user_id, $id);
        mysqli_stmt_execute($q);
    }

    if ($aksi == 'add_to_cart') {
        // Kalau buku sudah ada di cart, jumlahnya +1 (bukan bikin baris baru), tapi tidak boleh melebihi stok
        $cek = mysqli_prepare($conn, "SELECT id, jumlah FROM cart WHERE user_id = ? AND book_id = ?");
        mysqli_stmt_bind_param($cek, "ii", $user_id, $id);
        mysqli_stmt_execute($cek);
        $row_cart = mysqli_fetch_assoc(mysqli_stmt_get_result($cek));

        if ((int)$book['stok'] < 1) {
            $hasil = 'stok_habis';
        } elseif ($row_cart && (int)$row_cart['jumlah'] >= (int)$book['stok']) {
            $hasil = 'stok_penuh';
        } else {
            if ($row_cart) {
                $q = mysqli_prepare($conn, "UPDATE cart SET jumlah = jumlah + 1 WHERE id = ?");
                mysqli_stmt_bind_param($q, "i", $row_cart['id']);
            } else {
                $q = mysqli_prepare($conn, "INSERT INTO cart (user_id, book_id, jumlah) VALUES (?, ?, 1)");
                mysqli_stmt_bind_param($q, "ii", $user_id, $id);
            }
            mysqli_stmt_execute($q);
            $hasil = 'cart_ok';
        }
    }

    header("Location: book_detail.php?id=" . $id . "&info=" . $hasil);
    exit;
}

// ---------- RATING & ULASAN ----------
// Syarat: login + pernah beli buku ini dengan pesanan berstatus Selesai.
// Satu user cuma punya 1 ulasan per buku; kirim lagi = mengubah ulasan lama.
$error_review = "";
$pesan_review = [
    'ok'    => 'Terima kasih, ulasan kamu tersimpan.',
    'hapus' => 'Ulasan kamu dihapus.',
][is_string($_GET['ulasan'] ?? null) ? $_GET['ulasan'] : ''] ?? "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && in_array($aksi, ['simpan_review', 'hapus_review'])) {
    wajib_login();
    $user_id = $_SESSION['user_id'];

    if (!boleh_review($conn, $user_id, $id)) {
        $error_review = "Kamu bisa memberi rating setelah pesanan buku ini selesai.";
    } elseif ($aksi == 'hapus_review') {
        $q = mysqli_prepare($conn, "DELETE FROM reviews WHERE user_id = ? AND book_id = ?");
        mysqli_stmt_bind_param($q, "ii", $user_id, $id);
        mysqli_stmt_execute($q);
        header("Location: book_detail.php?id=$id&ulasan=hapus#ulasan");
        exit;
    } else {
        $rating = (int)($_POST['rating'] ?? 0);
        $komentar = trim($_POST['komentar'] ?? '');

        if ($rating < 1 || $rating > 5) {
            $error_review = "Pilih rating 1 sampai 5 bintang dulu.";
        } elseif (mb_strlen($komentar) > 1000) {
            $error_review = "Komentar maksimal 1000 karakter.";
        } else {
            $q = mysqli_prepare($conn, "
                INSERT INTO reviews (user_id, book_id, rating, komentar) VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE rating = VALUES(rating), komentar = VALUES(komentar)
            ");
            mysqli_stmt_bind_param($q, "iiis", $user_id, $id, $rating, $komentar);
            mysqli_stmt_execute($q);
            header("Location: book_detail.php?id=$id&ulasan=ok#ulasan");
            exit;
        }
    }
}

// Data buat tampilan: bisa review? ulasan milik sendiri? daftar semua ulasan
$boleh_review = isset($_SESSION['user_id']) && boleh_review($conn, $_SESSION['user_id'], $id);
$review_saya = null;
if ($boleh_review) {
    $q = mysqli_prepare($conn, "SELECT rating, komentar FROM reviews WHERE user_id = ? AND book_id = ?");
    mysqli_stmt_bind_param($q, "ii", $_SESSION['user_id'], $id);
    mysqli_stmt_execute($q);
    $review_saya = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
}
// Kalau form dikirim tapi gagal validasi, isian user tetap dipertahankan
$isi_rating   = (int)($_POST['rating'] ?? $review_saya['rating'] ?? 0);
$isi_komentar = $_POST['komentar'] ?? $review_saya['komentar'] ?? '';

$q = mysqli_prepare($conn, "
    SELECT reviews.*, users.nama FROM reviews
    JOIN users ON users.id = reviews.user_id
    WHERE reviews.book_id = ?
    ORDER BY reviews.updated_at DESC
    LIMIT 30
");
mysqli_stmt_bind_param($q, "i", $id);
mysqli_stmt_execute($q);
$daftar_review = mysqli_fetch_all(mysqli_stmt_get_result($q), MYSQLI_ASSOC);

// Status wishlist SEKARANG (buat nentuin teks tombol)
$is_wishlisted = false;
if (isset($_SESSION['user_id'])) {
    $cek2 = mysqli_prepare($conn, "SELECT id FROM wishlist WHERE user_id = ? AND book_id = ?");
    mysqli_stmt_bind_param($cek2, "ii", $_SESSION['user_id'], $id);
    mysqli_stmt_execute($cek2);
    mysqli_stmt_store_result($cek2);
    $is_wishlisted = mysqli_stmt_num_rows($cek2) > 0;
}

$judul_halaman = $book['judul'];
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="detail-section">
        <a href="javascript:history.back()" class="back-link">&larr; Kembali</a>

        <div class="detail-box">
            <div class="detail-left">
                <img src="<?php echo e(cover_url($book, 250, 350)); ?>" alt="<?php echo e($book['judul']); ?>">
            </div>

            <div class="detail-right">
                <h1><?php echo e($book['judul']); ?></h1>
                <p class="detail-penulis">oleh <?php echo e($book['penulis']); ?></p>
                <?php if ($book['genre']) { ?>
                    <span class="detail-genre"><?php echo e($book['genre']); ?></span>
                <?php } ?>
                <a href="#ulasan" class="detail-rating">
                    <?php echo bintang($book['rating_avg']); ?>
                    <span><?php echo e(teks_rating($book['rating_avg'], $book['rating_count'])); ?></span>
                    <?php if ($book['terjual'] > 0) { ?><span class="detail-sold">&middot; <?php echo (int)$book['terjual']; ?> terjual</span><?php } ?>
                </a>
                <p class="detail-price"><?php echo rupiah($book['harga']); ?></p>
                <p class="detail-deskripsi">
                    <?php echo $book['deskripsi'] ? nl2br(e($book['deskripsi'])) : '(Belum ada deskripsi untuk buku ini)'; ?>
                </p>

                <?php if ($pesan_wishlist) { ?>
                    <p class="auth-success"><?php echo e($pesan_wishlist); ?></p>
                <?php } ?>
                <?php if ($pesan_cart) { ?>
                    <p class="auth-success"><?php echo e($pesan_cart); ?></p>
                <?php } ?>
                <?php if ($error_cart) { ?>
                    <p class="auth-error"><?php echo e($error_cart); ?></p>
                <?php } ?>

                <div class="detail-actions">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="toggle_wishlist">
                        <button type="submit" class="btn-wishlist">
                            <?php echo $is_wishlisted ? 'Di Wishlist &middot; klik untuk hapus' : 'Tambah ke Wishlist'; ?>
                        </button>
                    </form>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add_to_cart">
                        <button type="submit" class="btn-cart">Tambah ke Keranjang</button>
                    </form>
                    <a href="checkout.php?beli=<?php echo (int)$book['id']; ?>" class="btn-buy">Beli Sekarang</a>
                </div>
            </div>
        </div>

        <!-- Rating & ulasan -->
        <div class="comment-section" id="ulasan">
            <h3>Rating &amp; Ulasan</h3>

            <?php if ($pesan_review) { ?><p class="auth-success"><?php echo e($pesan_review); ?></p><?php } ?>
            <?php if ($error_review) { ?><p class="auth-error"><?php echo e($error_review); ?></p><?php } ?>

            <?php if ($boleh_review) { ?>
                <form method="POST" action="book_detail.php?id=<?php echo (int)$id; ?>#ulasan" class="comment-form">
                    <input type="hidden" name="action" value="simpan_review">
                    <p class="review-label"><?php echo $review_saya ? 'Ubah rating kamu' : 'Beri rating untuk buku ini'; ?></p>
                    <div class="star-input">
                        <?php for ($n = 5; $n >= 1; $n--) { ?>
                            <input type="radio" name="rating" id="rate<?php echo $n; ?>" value="<?php echo $n; ?>" <?php echo $isi_rating == $n ? 'checked' : ''; ?>>
                            <label for="rate<?php echo $n; ?>" title="<?php echo $n; ?> bintang"><span class="sr-only"><?php echo $n; ?> bintang</span></label>
                        <?php } ?>
                    </div>
                    <textarea name="komentar" placeholder="Tulis ulasan kamu (opsional)..." rows="3" maxlength="1000"><?php echo e($isi_komentar); ?></textarea>
                    <button type="submit"><?php echo $review_saya ? 'Perbarui Ulasan' : 'Kirim Ulasan'; ?></button>
                </form>
                <?php if ($review_saya) { ?>
                    <form method="POST" action="book_detail.php?id=<?php echo (int)$id; ?>#ulasan" class="review-hapus" onsubmit="return confirm('Hapus ulasan kamu?');">
                        <input type="hidden" name="action" value="hapus_review">
                        <button type="submit" class="btn-link-danger">Hapus ulasan saya</button>
                    </form>
                <?php } ?>
            <?php } elseif (!isset($_SESSION['user_id'])) { ?>
                <p class="form-hint"><a href="login.php">Login</a> dan selesaikan pesanan buku ini untuk memberi rating.</p>
            <?php } else { ?>
                <p class="form-hint">Rating bisa diberikan setelah pesanan buku ini berstatus <strong>Selesai</strong>.</p>
            <?php } ?>

            <div class="comment-list">
                <?php if (!$daftar_review) { ?>
                    <p class="comment-empty">Belum ada ulasan untuk buku ini.</p>
                <?php } ?>
                <?php foreach ($daftar_review as $rv) { ?>
                    <div class="comment-item">
                        <p class="comment-author">
                            <?php echo e($rv['nama']); ?>
                            <?php echo bintang($rv['rating']); ?>
                            <span class="comment-date"><?php echo e(tanggal($rv['updated_at'], 'd M Y')); ?></span>
                        </p>
                        <?php if ($rv['komentar'] !== null && $rv['komentar'] !== '') { ?>
                            <p class="comment-text"><?php echo nl2br(e($rv['komentar'])); ?></p>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
