<?php
// ==========================================
// books.php - Daftar kategori/genre buku
// ==========================================
require_once 'includes/init.php';

// Kategori UTAMA (Fiksi, Non-Fiksi): parent_id-nya NULL
$result_main = mysqli_query($conn, "SELECT * FROM categories WHERE parent_id IS NULL");

$judul_halaman = 'Books';
include 'includes/header.php';
?>

    <div class="page-head">
        <h1>Jelajahi genre</h1>
        <p>Pilih genre favoritmu, lalu lihat semua bukunya.</p>
    </div>

    <section class="category-section">
        <div class="category-columns">
            <?php while ($main = mysqli_fetch_assoc($result_main)) {
                // Sub-genre dari kategori utama ini
                $stmt = mysqli_prepare($conn, "SELECT * FROM categories WHERE parent_id = ?");
                mysqli_stmt_bind_param($stmt, "i", $main['id']);
                mysqli_stmt_execute($stmt);
                $result_sub = mysqli_stmt_get_result($stmt);
            ?>
                <div class="category-column">
                    <h3>#<?php echo e(str_replace('-', '', $main['nama_kategori'])); ?></h3>
                    <ul class="genre-list">
                        <?php while ($sub = mysqli_fetch_assoc($result_sub)) { ?>
                            <li>
                                <a href="books_list.php?category=<?php echo (int)$sub['id']; ?>">
                                    <?php echo e($sub['nama_kategori']); ?>
                                </a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
