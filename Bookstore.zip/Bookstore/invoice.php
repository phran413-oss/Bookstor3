<?php
// ==========================================
// invoice.php - Struk / bukti pembayaran (sisi User)
//  - Sudah dibayar & diverifikasi (Diproses / Selesai) -> struk resmi "LUNAS" yang bisa dicetak
//  - Belum -> ringkasan pesanan + tombol ke halaman pembayaran
// ==========================================
require_once 'includes/init.php';
require_once 'includes/payment_methods.php';
wajib_login();

$order_id = (int)($_GET['order_id'] ?? 0);
list($order, $items) = ambil_order($conn, $order_id, $_SESSION['user_id']);

if (!$order) {
    die("Struk tidak ditemukan. <a href='riwayat_pesanan.php'>Kembali</a>");
}

$sudah_lunas = in_array($order['status'], [STATUS_DIPROSES, STATUS_SELESAI]);

$judul_halaman = 'Struk Pembelian';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="invoice-section">
        <?php $langkah_aktif = $sudah_lunas ? 4 : 3; include 'includes/steps.php'; ?>

        <?php if (!$sudah_lunas) { ?>

            <!-- ===== BELUM LUNAS: ringkasan biasa ===== -->
            <div class="summary-box">
                <p class="mb-15"><?php echo badge_status($order['status']); ?></p>
                <h2>Pesanan <?php echo e(nomor_order($order['id'])); ?></h2>
                <p class="invoice-meta"><?php echo e(tanggal($order['created_at'])); ?></p>

                <div class="summary-items">
                    <?php foreach ($items as $item) { ?>
                        <div class="checkout-item-row">
                            <span><?php echo e($item['judul']); ?> x<?php echo (int)$item['jumlah']; ?></span>
                            <span><?php echo rupiah($item['subtotal']); ?></span>
                        </div>
                    <?php } ?>
                    <div class="checkout-item-row checkout-total-row">
                        <strong>Total</strong>
                        <strong><?php echo rupiah($order['total_harga']); ?></strong>
                    </div>
                </div>

                <p class="form-hint">Metode Pembayaran: <strong><?php echo e($order['metode_pembayaran']); ?></strong></p>

                <?php if ($order['status'] == STATUS_DIBATALKAN) { ?>
                    <p class="form-hint">Pesanan ini sudah dibatalkan.</p>
                <?php } else { ?>
                    <p class="form-hint">Struk resmi akan tersedia di halaman ini setelah pembayaranmu diverifikasi admin.</p>
                    <a href="pembayaran.php?order_id=<?php echo (int)$order['id']; ?>" class="btn-checkout">
                        <?php echo $order['status'] == STATUS_MENUNGGU_VERIF ? 'Lihat Status Pembayaran' : 'Bayar / Upload Bukti'; ?>
                    </a>
                <?php } ?>
            </div>

        <?php } else { ?>

            <!-- ===== SUDAH LUNAS: struk resmi gaya thermal printer ===== -->
            <div class="receipt">
                <div class="receipt-header">
                    <p class="receipt-store">📚 BOOKSTORE</p>
                    <p class="receipt-address">
                        Jl. Pelajar Indonesia No. 45, Kebayoran Baru<br>
                        Jakarta Selatan, 12190
                    </p>
                    <p class="receipt-title">BUKTI PEMBAYARAN</p>
                </div>

                <div class="receipt-dashed"></div>

                <div class="receipt-meta">
                    <div class="receipt-meta-row"><span>No. Order</span><span><?php echo e(nomor_order($order['id'])); ?></span></div>
                    <div class="receipt-meta-row"><span>Tgl Pesan</span><span><?php echo e(tanggal($order['created_at'], 'd-m-Y H:i')); ?></span></div>
                    <?php if ($order['waktu_bayar']) { ?>
                        <div class="receipt-meta-row"><span>Tgl Bayar</span><span><?php echo e(tanggal($order['waktu_bayar'], 'd-m-Y H:i')); ?></span></div>
                    <?php } ?>
                    <div class="receipt-meta-row"><span>Pembeli</span><span><?php echo e($order['nama_user']); ?></span></div>
                    <div class="receipt-meta-row"><span>Metode</span><span><?php echo e($order['metode_pembayaran']); ?></span></div>
                </div>

                <div class="receipt-dashed"></div>

                <div class="receipt-items">
                    <?php foreach ($items as $item) { ?>
                        <div class="receipt-item-name"><?php echo e($item['judul']); ?></div>
                        <div class="receipt-item-detail">
                            <span><?php echo (int)$item['jumlah']; ?> x <?php echo number_format($item['harga'], 0, ',', '.'); ?></span>
                            <span><?php echo number_format($item['subtotal'], 0, ',', '.'); ?></span>
                        </div>
                    <?php } ?>
                </div>

                <div class="receipt-dashed"></div>

                <div class="receipt-meta">
                    <div class="receipt-meta-row receipt-total"><span>TOTAL</span><span><?php echo number_format($order['total_harga'], 0, ',', '.'); ?></span></div>
                </div>

                <div class="receipt-dashed"></div>

                <p class="receipt-status">Status Pembayaran: <strong class="receipt-lunas">LUNAS</strong></p>
                <p class="receipt-status">Status Pesanan: <strong><?php echo e($order['status']); ?></strong></p>

                <?php if ($order['bukti_pembayaran']) { ?>
                    <div class="receipt-dashed print-hide"></div>
                    <p class="receipt-status print-hide">Bukti transfer yang kamu kirim:</p>
                    <p class="receipt-status print-hide"><a href="<?php echo e(bukti_url($order['bukti_pembayaran'])); ?>" target="_blank">📄 Buka bukti (PDF)</a></p>
                <?php } ?>

                <p class="receipt-footer">** Terima kasih sudah belanja di Bookstore **</p>
            </div>

            <!-- Tombol di LUAR div.receipt supaya tidak ikut ter-print -->
            <div class="invoice-actions print-hide">
                <button type="button" onclick="window.print()" class="btn-checkout">
                    Cetak / Download Struk
                </button>
            </div>

        <?php } ?>

        <div class="invoice-actions print-hide">
            <a href="riwayat_pesanan.php" class="back-link">&larr; Pesanan Saya</a>
        </div>

    </section>

<?php include 'includes/footer.php'; ?>
