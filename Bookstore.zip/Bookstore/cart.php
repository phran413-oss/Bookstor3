<?php
// ==========================================
// cart.php - Keranjang Belanja
// ==========================================
require_once 'includes/init.php';
wajib_login();

$user_id = $_SESSION['user_id'];

// ---------- HAPUS ITEM ----------
// "AND user_id = ?" penting: user A tidak boleh hapus cart milik user B
if (isset($_GET['hapus'])) {
    $cart_id = (int)$_GET['hapus'];
    $stmt = mysqli_prepare($conn, "DELETE FROM cart WHERE id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $cart_id, $user_id);
    mysqli_stmt_execute($stmt);
    header("Location: cart.php");
    exit;
}

// ---------- UBAH JUMLAH ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'update_qty') {
    $cart_id = (int)$_POST['cart_id'];
    $jumlah = max(1, (int)$_POST['jumlah']);   // minimal 1

    $stmt = mysqli_prepare($conn, "UPDATE cart SET jumlah = ? WHERE id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "iii", $jumlah, $cart_id, $user_id);
    mysqli_stmt_execute($stmt);
    header("Location: cart.php");
    exit;
}

// ---------- ISI CART ----------
$items = ambil_isi_cart($conn, $user_id);
$total_harga = array_sum(array_column($items, 'subtotal'));

$judul_halaman = 'Keranjang';
include 'includes/header.php';
?>

    <section class="cart-section">
        <?php $langkah_aktif = 1; include 'includes/steps.php'; ?>
        <h2>Keranjang Belanja</h2>

        <?php if (count($items) == 0) { ?>
            <div class="empty-state">
                <?php echo ikon('cart', 40); ?>
                <strong>Keranjangmu masih kosong</strong>
                <p>Yuk cari buku yang mau kamu baca.</p>
                <a href="books.php" class="btn-checkout">Jelajahi buku</a>
            </div>
        <?php } else { ?>
            <div class="cart-layout">
            <div class="cart-table">
                <?php foreach ($items as $item) { ?>
                    <div class="cart-row">
                        <img src="<?php echo e(cover_url($item, 80, 110)); ?>" alt="<?php echo e($item['judul']); ?>" class="cart-img">
                        <div class="cart-info">
                            <p class="cart-title"><?php echo e($item['judul']); ?></p>
                            <p class="cart-price"><?php echo rupiah($item['harga']); ?></p>
                        </div>

                        <form method="POST" action="" class="cart-qty-form">
                            <input type="hidden" name="action" value="update_qty">
                            <input type="hidden" name="cart_id" value="<?php echo (int)$item['cart_id']; ?>">
                            <input type="number" name="jumlah" value="<?php echo (int)$item['jumlah']; ?>" min="1" class="cart-qty-input">
                            <button type="submit" class="btn-update-qty">Update</button>
                        </form>

                        <p class="cart-subtotal"><?php echo rupiah($item['subtotal']); ?></p>
                        <a href="cart.php?hapus=<?php echo (int)$item['cart_id']; ?>"
                           class="btn-delete"
                           onclick="return confirm('Hapus buku ini dari keranjang?');">Hapus</a>
                    </div>
                <?php } ?>
            </div>

            <div class="cart-total-box">
                <p class="cart-total-text"><span>Total</span> <strong><?php echo rupiah($total_harga); ?></strong></p>
                <a href="checkout.php" class="btn-checkout">Lanjut ke Checkout</a>
            </div>
            </div>
        <?php } ?>
    </section>

<?php include 'includes/footer.php'; ?>
