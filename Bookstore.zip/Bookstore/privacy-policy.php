<?php
// ==========================================
// privacy-policy.php - Halaman statis
// ==========================================
require_once 'includes/init.php';

$judul_halaman = 'Privacy Policy';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="static-page-section">
        <h1>Privacy Policy</h1>
        <p class="static-updated">Terakhir diperbarui: <?php echo date('d F Y'); ?></p>

        <h3>1. Informasi yang Kami Kumpulkan</h3>
        <p>Kami mengumpulkan informasi yang kamu berikan saat mendaftar akun, seperti nama dan alamat email, serta data pesanan seperti alamat pengiriman saat kamu melakukan checkout.</p>

        <h3>2. Penggunaan Informasi</h3>
        <p>Informasi yang kami kumpulkan digunakan untuk memproses pesanan, mengelola akun kamu, dan meningkatkan pengalaman belanja di Bookstore.</p>

        <h3>3. Keamanan Data</h3>
        <p>Kami menyimpan password kamu dalam bentuk terenkripsi dan tidak pernah membagikan data pribadi kamu ke pihak ketiga tanpa izin.</p>

        <h3>4. Hak Kamu</h3>
        <p>Kamu berhak meminta penghapusan akun dan data pribadi kapan saja dengan menghubungi tim support kami.</p>

        <p class="static-note">
            Catatan: Halaman ini adalah contoh placeholder untuk keperluan latihan/pengembangan, bukan kebijakan privasi yang berlaku secara hukum.
        </p>
    </section>

<?php include 'includes/footer.php'; ?>
