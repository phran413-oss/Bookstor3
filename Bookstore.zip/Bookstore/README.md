# Bookstore (PHP + MySQL)

Toko buku sederhana: user (katalog, wishlist, keranjang, checkout, bayar + upload bukti) dan admin (kelola buku/kategori, verifikasi pembayaran).

## Cara jalanin (XAMPP)
1. Taruh folder ini di `htdocs/Bookstore`.
2. phpMyAdmin → buat database `bookstore` → Import `database/bookstore.sql`.
   (Kalau database lama sudah ada: jalankan `database/migrasi_pembayaran.sql` lalu `database/migrasi_rating.sql`.)
3. Buka `http://localhost/Bookstore/`.
4. Akun contoh: `admin@bookstore.com` / `admin123` (admin), `budi@mail.com` / `user123` (user).
5. **Ganti nomor rekening / e-wallet** di `includes/payment_methods.php`. Gambar QRIS toko → `assets/images/qris.png`.

## Alur pesanan
`Menunggu Pembayaran` → user upload bukti → `Menunggu Verifikasi` → admin cek:
- **Terima** → `Diproses` (user dapat struk "LUNAS") → admin **Tandai Selesai** → `Selesai`
- **Tolak** (+ alasan) → `Pembayaran Ditolak` → user upload ulang

User bisa membatalkan selama belum bayar (stok dikembalikan).

## Rating, Best seller & Trending now
- **Rating**: di halaman detail buku, user yang pernah membeli buku itu (pesanan berstatus **Selesai**) bisa kasih 1–5 bintang + ulasan (opsional). 1 user = 1 ulasan per buku; kirim lagi = mengubah, dan bisa dihapus.
- **Best seller**: otomatis dari jumlah eksemplar paling banyak terjual (pesanan berstatus `Diproses` / `Selesai`; yang belum bayar, ditolak, atau dibatalkan tidak dihitung). Maks. 8 buku.
- **Trending now**: otomatis dari rating tertinggi memakai rata-rata berbobot, jadi 1 ulasan bintang 5 tidak langsung mengalahkan buku dengan banyak ulasan bagus. Atur bobotnya lewat `BOBOT_RATING_TRENDING` di `includes/helpers.php`. Maks. 8 buku.
- Centang manual "Best seller" / "Trending now" di form admin sudah dihapus (kolom `is_bestseller` & `is_trending` dibuang dari tabel `books`).

## Struktur
```
index.php, books.php, ...   halaman user (logika di atas file, tampilan di bawah)
admin/                      halaman admin
includes/
  init.php                  session + koneksi + helper (di-require paling atas tiap halaman)
  config.php                setting database
  helpers.php               e(), rupiah(), status, upload gambar, query bersama
  payment_methods.php       daftar metode & tujuan bayar
  header.php / footer.php   layout user
  admin_header.php / admin_footer.php   layout admin
  book_card.php, form_buku.php          potongan tampilan yang dipakai ulang
database/                   bookstore.sql (install baru), migrasi_pembayaran.sql (DB lama)
uploads/bukti/              bukti pembayaran user (otomatis jadi PDF terkompresi: bukti_000010_xxxx.pdf)
assets/                     css, icons, images/books
```

## Kompres bukti pembayaran (butuh ekstensi GD)
Bukti yang diupload dikompres jadi PDF memakai ekstensi PHP **GD**. Kalau muncul error `imagecreatefromstring`, aktifkan dulu:
1. XAMPP Control Panel → Apache → **Config** → `PHP (php.ini)`.
2. Cari baris `;extension=gd`, hapus titik koma di depannya jadi `extension=gd`.
3. Simpan, lalu **Stop → Start** Apache.
Tanpa GD, upload JPG tetap jalan tapi tidak dikompres, dan PNG/WEBP ditolak dengan pesan jelas.
