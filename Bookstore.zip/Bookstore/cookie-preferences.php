<?php
// ==========================================
// cookie-preferences.php - Halaman statis
// ==========================================
require_once 'includes/init.php';

$judul_halaman = 'Cookie Preferences';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="static-page-section">
        <h1>Cookie Preferences</h1>
        <p class="static-updated">Terakhir diperbarui: <?php echo date('d F Y'); ?></p>

        <h3>1. Apa itu Cookie?</h3>
        <p>Cookie adalah file kecil yang disimpan di browser kamu untuk membantu website mengingat informasi, seperti status login (session), agar kamu tidak perlu login ulang setiap membuka halaman baru.</p>

        <h3>2. Cookie yang Kami Gunakan</h3>
        <p>Bookstore menggunakan session cookie untuk menjaga status login kamu selama sesi belanja berlangsung. Cookie ini otomatis terhapus saat kamu logout atau menutup browser.</p>

        <h3>3. Mengatur Cookie</h3>
        <p>Kamu dapat menghapus atau memblokir cookie melalui pengaturan browser kamu, namun beberapa fitur seperti login dan keranjang belanja mungkin tidak akan berfungsi dengan baik.</p>

        <p class="static-note">
            Catatan: Halaman ini adalah contoh placeholder untuk keperluan latihan/pengembangan, bukan kebijakan privasi yang berlaku secara hukum.
        </p>
    </section>

<?php include 'includes/footer.php'; ?>
